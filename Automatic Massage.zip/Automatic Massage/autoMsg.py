import pyautogui
#import time
while True:
    #time.sleep(3) # It will wait 3 sec and send the msg again ang again
    pyautogui.typewrite('F.U')
    pyautogui.press('enter')
