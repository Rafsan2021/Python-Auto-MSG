import pyautogui
import time
while True:
    time.sleep(3) # It will wait 3 sec and send the msg again ang again
    pyautogui.typewrite('Hell0!!')
    pyautogui.press('enter')
Hell0!!
